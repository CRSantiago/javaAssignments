import java.util.*;
import java.nio.charset.Charset;
import java.nio.file.*;
import java.io.*;

public class Homework5 {

	public static void main(String[] args) {
		Path path = Paths.get("example.bin");
		try (OutputStream outputStream = 	Files.newOutputStream(path,
				StandardOpenOption.CREATE, StandardOpenOption.APPEND);
				BufferedOutputStream buffered =
						new BufferedOutputStream(outputStream)) {
			BitOutputStream bitOut = new BitOutputStream(buffered);
			bitOut.WriteBit('0');
			bitOut.WriteBit('1');
			bitOut.WriteBit("101110");
			bitOut.WriteBit("110");
			bitOut.OutputByte();
			bitOut.close();
		} catch (IOException e) {
			// do something with e
		}
	}

}
