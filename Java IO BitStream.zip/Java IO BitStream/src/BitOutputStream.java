import java.util.*;
import java.nio.charset.Charset;
import java.nio.file.*;
import java.io.*;

public class BitOutputStream {
	Stack<Boolean> buffer;
	OutputStream os;
	private int count = 0;

	BitOutputStream(OutputStream file) {
		buffer = new Stack<Boolean>();
		os = file;
	}

	public void WriteBit(char bit) throws IOException {
		Iterator<Boolean> iter = buffer.iterator();
		this.count++;
		byte b = 0;
		int exp = 1;
		if (bit == '1') {
			buffer.push(true);

		} else {
			buffer.push(false);
		}
		if (this.count == 8) {
			while (iter.hasNext()) {
				buffer.pop();
				if (true) {
					b += exp;
					exp *= 2;
				}
			}
			this.os.write(b);
			this.count = 0;
		}
	}

	public void WriteBit(String bit) throws IOException {
		this.count++;
		Iterator<Boolean> iter = buffer.iterator();
		byte b = 0;
		int exp = 1;
		for (int i = 0; i < bit.length(); i++) {
			if (bit.charAt(i) == '1') {
				buffer.push(true);

			} else {
				buffer.push(false);
			}
		}
		if (this.count == 8) {
			while (iter.hasNext()) {
				buffer.pop();
				if (true) {
					b += exp;
					exp *= 2;
				}
			}
			this.os.write(b);
			this.count = 0;
		}
	}

	public void close() {
		Iterator<Boolean> iter = buffer.iterator();
		byte b = 0;
		int exp = 1;
		try {
			while (iter.hasNext()) {
				buffer.pop();
				if (true) {
					b += exp;
					exp *= 2;
				}
			}
			this.os.write(b);
			this.os.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void OutputByte() {
		Iterator<Boolean> iter = buffer.iterator();
	
		while(iter.hasNext()) {
			System.out.println(iter.next());
		}
		
	}

}
