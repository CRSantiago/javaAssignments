/*
 * Christopher Santiago
 * 09/09/18
 * Beer Assignment: Working with user import of beer consumption to answer these questions
 * 
1. How many beers will the user consume over the course of the year?
2.	Assuming a beer is 150 calories, how many calories will the user take in from beer alone over the course of the year?
3.	How much weight can the user expect to gain in one year based on the number of 12-ounce beers they consume every day?
4.	How much the user will spend on beer this year?

*/
import java.util.Scanner;
import java.text.DecimalFormat;

public class BeerAssignment {

	public static void main(String[] args) {

		Scanner userAverageBeerIntake = new Scanner(System.in);
		Scanner userAverageAmountSpent = new Scanner(System.in);
		double averageBeerIntake;
		double averageAmountSpent;

		//prompts user for average amount of beer consumed daily
		System.out.println("On average, how many beers do you expect to consume each day: ");
		averageBeerIntake = userAverageBeerIntake.nextDouble();

		//prompts user for average amount spent on 12-oz beer
		System.out.println("On average, how much do you expect to spend on a single 12-ounce can of beer: ");
		averageAmountSpent = userAverageAmountSpent.nextDouble();
		
		if (averageAmountSpent > 0 && averageBeerIntake > 0) {
		
		//variables to calculate yearly calorie intake, yearly amount spent on beer, and potential weight gain respectively
		double yearlyCalorieIntake = yearlyAverageBeerIntake(averageBeerIntake) * 150;
		double yearlyAmountSpent = yearlyAverageBeerIntake(averageBeerIntake) * averageAmountSpent;
		double yearlyWeightGain = averageBeerIntake * 15;
		
		//creates a format for final printed numbers to only have two decimal places
		DecimalFormat twoPlaces = new DecimalFormat("0.00");

		//first print statement shows amount spent on beer and quantity of beer consumed in a year.
		//second print statement shows yearly calorie intake.
		//third print statement shows potential weight gain based on beer consumption
		System.out.println("That is approximately $" + twoPlaces.format(yearlyAmountSpent) + " spent on "+ twoPlaces.format(yearlyAverageBeerIntake(averageBeerIntake)) + " beers in one year.");
		System.out.println("In one year, you will consume " + twoPlaces.format(yearlyCalorieIntake) + " from beer alone.");
		System.out.println("Without diet or exercise to counter these calories, you can expect to gain " + twoPlaces.format(yearlyWeightGain) + " pounds from drinking that much beer this year.");
		} else {
			
			System.out.println("You did not enter a positive number.");
			
		}//end of if
	}

	//method to produce number of beers consumed in a year. Used for calculations through the rest of the program
	public static double yearlyAverageBeerIntake(double averageBeerIntake) {
		double result = 0;

		for (int i = 0; i < 365; i++) {

			result += averageBeerIntake;

		}

		return result;
	}//end of method

	

}
