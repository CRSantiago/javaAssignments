
public class RaceCar implements Vehicle,OnAndOff,Race {

		private int speed;
		
		public int getSpeed() {
			return speed;
		}

		public void setSpeed(int speed) {
			this.speed = speed;
		}

		public void speedUp(int increment) {
			this.speed += increment;
		}

		public void applyBrakes(int decrement) {
			this.speed -= decrement;
		}
		
		public void turnOn() {
			System.out.println("The car is now on!");
		}

		
		public void turnOff() {
			System.out.println("The car is now off.");
		}

		public void startRace() {
			System.out.println("The race has began!");
		}
	
		public void endRace() {
			System.out.println("The race has now ended.");
		}
		
		public String toString() {
			return speed + " Mph";
		}
}
