
public interface Vehicle {

	public abstract void speedUp(int speed);
	public abstract void applyBrakes(int speed);
	
}
