
public interface OnAndOff {
	
	public abstract void turnOn();
	public abstract void turnOff();

}
