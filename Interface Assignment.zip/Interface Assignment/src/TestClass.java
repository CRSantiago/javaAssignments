import java.util.Scanner;

public class TestClass {

	public static void main(String[] args) {

		Scanner keyboard = new Scanner(System.in);
		Scanner keyboard2 = new Scanner(System.in);
		int carChoice;
		int menuChoice;
		int raceLength = 0;

		RaceCar car1 = new RaceCar();
		RaceCar car2 = new RaceCar();		

		System.out.println("<----Lets race!---->");
		System.out.println("Which car do you think will win, car 1 or car 2?");
		carChoice = keyboard2.nextInt();

		do {
			System.out.println("Press 1 to start the race: ");
			System.out.println("Press 2 to exit race: ");
			menuChoice = keyboard.nextInt();

			switch(menuChoice) {

			case 1:
				startRace(car1,car2,carChoice,raceLength);
				break;

			case 2:
				endRace(car1,car2);
				break;
			}

		}while(menuChoice != 2);

	}
	
	public static void startRace(RaceCar car1, RaceCar car2,int carChoice,int raceLength) {
		
		System.out.println("The first car is starting up.");
		car1.turnOn();
		System.out.println("The second car is starting up.");
		car2.turnOn();
		car1.startRace();

		do {
			car1.setSpeed(0);
			car2.setSpeed(0);
			car1.speedUp(50);
			car2.speedUp(60);
			raceLength += 1;
		}while(raceLength != 10);
		
		System.out.println("The race is now over.");
		
		if(carChoice == 2) {
			System.out.println("You are correct! Car 2 won!");
		}else {
			System.out.println("Sorry, car 2 was actually the winner.");
		}
		
		System.out.println("Car 1 top speed was " + car1.toString());
		System.out.println("Car 2 top speed was " + car2.toString());
		car1.applyBrakes(50);
		car2.applyBrakes(60);
		
	}
	
	public static void endRace(RaceCar car1, RaceCar car2) {
		
		System.out.println("Thanks for playing!");
		System.out.println("The first car is turning off.");
		car1.turnOff();
		System.out.println("The second car is turning off.");
		car2.turnOff();
		
	}

}

