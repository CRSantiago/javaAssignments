
public interface Race {
	
	public abstract void startRace();
	public abstract void endRace();

}
