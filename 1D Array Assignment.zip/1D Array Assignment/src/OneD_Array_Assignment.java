//Christopher Santiago
//09.27.18
//Working with arrays and methods


import java.util.Scanner;
import java.util.Random;
import java.text.DecimalFormat;
import java.util.Arrays;

public class OneD_Array_Assignment {

	public static void main(String[] args) {

		//scans for user input and saved as choice variable
		Scanner keyboard = new Scanner(System.in);
		int choice;

		System.out.println("Enter how many numbers you want to be randomly generated: ");
		choice = keyboard.nextInt();

		//random number generator
		Random generator = new Random();
		int[] randomNumberArray = new int[choice];

		//print statement with for loop to populate the array randomNumberArray
		System.out.println("The numbers generated are: ");
		for (int i = 0; i < choice; i++) {

			randomNumberArray[i] = generator.nextInt(100);
			System.out.println(randomNumberArray[i]);
		}//end of for loop

		//methods used to carry out task
		sortArray(randomNumberArray);

		searchArray(randomNumberArray);
		
		averageOfArray(randomNumberArray);

		getMaxAndMinOfArray(randomNumberArray);

	}//end of main method

	public static void sortArray(int[] array) {

		//sort array method
		Arrays.sort(array);
		
		//print statement with for loop to print out array elements
		System.out.println("The numbers sorted are: ");

		for (int i = 0; i < array.length; i++) {

			System.out.println(array[i]);

		}//end of for loop

	}//end of sortArray method

	public static void searchArray(int[] array) {

		//scans for user input of number to be searched for. Store is search number variable
		Scanner keyboard = new Scanner(System.in);
		int searchNumber;
		
		//print statement with the prompt for user
		System.out.println("Please enter a number to search for between 1 and 100");
		searchNumber = keyboard.nextInt();

		boolean found = false;

		//for loop to run through array to loop for match
		for (int i = 0; i < array.length; i++) {

			//if match is found. found boolean is changed to true to match sure the next if statement is not executed. Then it prints what index your number
			if (searchNumber == array[i]) {
				found = true;
				System.out.println("We found your number at index " + i);

			}
		}
		
		//if searchNumber not found print out the following statement
		if (!found) {

			System.out.println("We did not find your number.");

		}//end of for loop


	}//end of searchArray method
	
	public static void averageOfArray(int[] array) {

		double average = 0.0, sum = 0;
		
		//used to format average to two decimal places
		DecimalFormat twoPlaces = new DecimalFormat("0.00");

		//for loop used to add array elements create a sum
		for (int i = 0; i < array.length; i++) {

			sum += array[i];

		}//end of for loop

		average = sum / array.length;

		System.out.println("The average of the numbers in the array is: " + twoPlaces.format(average));

	}//end of averageOfArray method

	public static void getMaxAndMinOfArray(int[] array) {

		//sort array method to determine min and max. min will be index[0] and max will be last index
		Arrays.sort(array);

		System.out.println("The minimum number in this array is: " + array[0]);
		System.out.println("The maximum in this array is: " + array[array.length - 1]);

	}

}
