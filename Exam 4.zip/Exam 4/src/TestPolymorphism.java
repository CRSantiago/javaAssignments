import java.util.Scanner;


public class TestPolymorphism {

	public static void main(String[] args) {
		
		int menuChoice;
		Scanner keyboard = new Scanner(System.in);
		Person people[] = new Person[100];
		
		//populates the people array with various child classes of Person
		people[0] = new BaseballPlayer("Hank", "H.", "Aaron", 26, "Milwaukee Braves", "Outfield", 3, "Right");
		people[1] = new FootballPlayer("Terry", "F.", "Bradshaw", 31, "Pittsburgh Steelers", "Quarterback", "Offense");
		people[2] = new HockeyPlayer("Mario", "", "Lemieux", 29, "Boston Bruins", "Golie", "Bauer");
		people[3] = new Golfer("Tiger","T.", "Woods", 42, "USA", "Golfer", "Nike Golf");
		people[4] = new BaseballPlayer("Barry", "B.", "Bonds", 28, "San Francisco Giants", "Outfield", 2, "Left");
		people[5] = new FootballPlayer("Payton", "A.", "Manning", 23, "Indianapolis Colts", "QuarterBack", "Offense");
		people[6] = new HockeyPlayer("Wayne","", "Gretzky", 33, "Edmonton Oilers", "Centerman", "Warrior");
		people[7] = new Golfer("Phil","A.", "Mickelson",43, "USA", "Golfer", "Callaway");
		people[8] = new FootballPlayer("Ben", "T.", "Roethlisberger", 36, "Pitssburgh Steelers", "Quarterback", "Offense");
		people[9] = new HockeyPlayer("Alex", "M.", "Ovechkin", 33, "Washington Capital", "Skater", "CCM" );
		people[10] = new Golfer("Roy", "", "McIlroy", 29, "Northern Ireland", "Golfer", "OMEGA");
		people[11] = new BaseballPlayer("Nolan", "", "Arenado",27, "Colorado Rockies", "3B", 5, "Right");
		people[12]= new FootballPlayer("Todd", "", "Gurley II", 24, "Los Angeles Rams", "Running Back", "Offense");
		
		//do.. while loop to display menu
		do {
			System.out.println("<------Menu------>");
			System.out.println("1. Display all athletes created: ");
			System.out.println("2. Begin each sports game: ");
			System.out.println("3. Watch all athletes perform their sport: ");
			System.out.println("4. Exit program.");
			System.out.println("<---------------->");
			menuChoice = keyboard.nextInt();
			
			//switch to run cases based on menu choice
			switch(menuChoice) {
			
			case 1: 
				//for loop to display contents of people array. Contains if statement to NOT display null indexes
				for(int i= 0; i < people.length; i++) {
					if(people[i] != null) {
					System.out.println(people[i] + "\n");
					}
				}
				break;
				
			case 2:
				//case to display startPlay method for corresponding athlete type
				((BaseballPlayer) people[0]).startPlay();
				((FootballPlayer) people[1]).startPlay();
				((HockeyPlayer) people[2]).startPlay();
				((Golfer) people[3]).startPlay();
				break;
				
			case 3:
				// case to display doThis method for each corresponding athlete type
				((BaseballPlayer) people[0]).doThis();
				((FootballPlayer) people[1]).doThis();
				((HockeyPlayer) people[2]).doThis();
				((Golfer) people[3]).doThis();
				((BaseballPlayer) people[4]).doThis();
				((FootballPlayer) people[5]).doThis();
				((HockeyPlayer) people[6]).doThis();
				((Golfer) people[7]).doThis();
				((FootballPlayer) people[8]).doThis();
				((HockeyPlayer) people[9]).doThis();
				((Golfer) people[10]).doThis();
				((BaseballPlayer) people[11]).doThis();
				((FootballPlayer) people[12]).doThis();
				break;
				
			case 4:
				System.out.println("Thanks for playing. Bye!");
				break;
				
			default:
				System.out.println("Please enter a valid menu option.");
			
			}//end of switch
			
		} while (menuChoice != 4);
		
	}//end of main

}// end of TestPolymorphism Class
