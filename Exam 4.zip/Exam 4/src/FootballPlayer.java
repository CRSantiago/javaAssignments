
public class FootballPlayer extends Athlete implements Actions, StartPlay{
	
	private String specialty;
	
	public FootballPlayer(String firstName, String middleInitial, String lastName, int age, String team, String position, String specialty) {
		
		super(firstName, middleInitial, lastName, age, team, position);
		setSpecialty(specialty);
		
	}
	
	public boolean equals(Object obj) {
		if(!(obj instanceof FootballPlayer)) {
			return false;
		}
		
		boolean result = false;
		
		if (this.getTeam() == ((FootballPlayer)obj).getTeam()) {
			result = true;
		}
		
		return result;
	}

	public String getSpecialty() {
		return specialty;
	}

	public void setSpecialty(String specialty) {
		this.specialty = specialty;
	}
	
	public void doThis() {
		System.out.println("You made a tackle!");
	}
	
	public void startPlay() {
		System.out.println("The ball has been snapped!");
	}
	
	public String toString() {
		return "Football Player" + "\n" + "Name: " + getFirstName() + " " + getMiddleInitial() + " " + getLastName() + "\n" + "Age: " + getAge() + "\n" + "Team: " + getTeam() + "\n" + "Position: " + getPosition() + "\n" + "Specialty: " + specialty;
	}

}
