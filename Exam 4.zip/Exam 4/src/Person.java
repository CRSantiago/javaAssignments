
public class Person {
	
	private String name;
	private String firstName;
	private String middleInitial;
	private String lastName;
	private int age;
	
	public Person(String firstName,String middleInitial, String lastName, int age) {
		
		setFirstName(firstName);
		setMiddleInitial(middleInitial);
		setLastName(lastName);
		setAge(age);
		
	}
	
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleInitial() {
		return middleInitial;
	}

	public void setMiddleInitial(String middleInitial) {
		this.middleInitial = middleInitial;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}

}
