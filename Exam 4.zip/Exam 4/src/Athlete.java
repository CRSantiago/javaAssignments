
public class Athlete extends Person{
	
	private String team;
	private String position;
	
	public Athlete(String firstName,String middleInitial, String lastName, int age, String team, String position) {
		
		super(firstName, middleInitial, lastName, age);
		setTeam(team);
		setPosition(position);
		
	}
	
	public String getTeam() {
		return team;
	}
	public void setTeam(String team) {
		this.team = team;
	}
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		this.position = position;
	}
	
	

}
