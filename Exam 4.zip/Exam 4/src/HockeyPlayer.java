
public class HockeyPlayer extends Athlete implements Actions, StartPlay{
	
	private String stickBrand;
	
	public HockeyPlayer(String firstName, String middleInitial, String lastName, int age, String team, String position, String stickBrand) {
		
		super(firstName, middleInitial, lastName, age, team, position);
		setStickBrand(stickBrand);
		
	}
	
	public boolean equals(Object obj) {
		if(!(obj instanceof HockeyPlayer)) {
			return false;
		}
		
		boolean result = false;
		
		if (this.getTeam() == ((HockeyPlayer)obj).getTeam()) {
			result = true;
		}
		
		return result;
	}

	public String getStickBrand() {
		return stickBrand;
	}

	public void setStickBrand(String stickBrand) {
		this.stickBrand = stickBrand;
	}
	
	public void doThis() {
		System.out.println("You are stuck in the penalty box for 5 minutes.");
	}
	
	public void startPlay() {
		System.out.println("The puck has been dropped!");
	}
	
	public String toString() {
		return "Hockey Player" + "\n" + "Name: " + getFirstName() + " " + getMiddleInitial() + " " + getLastName() + "\n" + "Age: " + getAge() + "\n" + "Team: " + getTeam() + "\n" + "Position: " + getPosition() + "\n" + "Stick Brand: " + stickBrand;
	}

}
