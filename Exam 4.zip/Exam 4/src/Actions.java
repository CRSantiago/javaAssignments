
public interface Actions {

	public abstract void doThis();
	
}
