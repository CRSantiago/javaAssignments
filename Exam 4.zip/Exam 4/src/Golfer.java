
public class Golfer extends Athlete implements Actions, StartPlay{
		
		private String mainSponser;

		public Golfer(String firstName, String middleInitial, String lastName, int age, String team, String position, String mainSponser) {
			
			super(firstName, middleInitial, lastName, age, team, position);
			setMainSponser(mainSponser);
			
		}
		
		public boolean equals(Object obj) {
			if(!(obj instanceof Golfer)) {
				return false;
			}
			
			boolean result = false;
			
			if (this.getTeam() == ((Golfer)obj).getTeam()) {
				result = true;
			}
			
			return result;
		}
		
		public String getMainSponser() {
			return mainSponser;
		}

		public void setMainSponser(String mainSponser) {
			this.mainSponser = mainSponser;
		}
		
		public void doThis() {
			System.out.println("Your putt put the ball in the hole!");
		}
		
		public void startPlay() {
			System.out.println("It's tee off time!");
		}
		
		public String toString() {
			return "Golfer" + "\n" + "Name: " + getFirstName() + " " + getMiddleInitial() + " " + getLastName() + "\n" + "Age: " + getAge() + "\n" + "Team: " + getTeam() + "\n" + "Position: " + getPosition() + "\n" + "Main Sponser: "+ mainSponser;
		}
		
	}


