
public class BaseballPlayer extends Athlete implements Actions, StartPlay{
	
	private int battingPosition;
	private String battingHand;
	
	public BaseballPlayer(String firstName, String middleInitial, String lastName, int age, String team, String position, int battingPosition, String battingHand) {
		
		super(firstName, middleInitial, lastName, age, team, position);
		setBattingPosition(battingPosition);
		setBattingHand(battingHand);
		
	}
	
	public boolean equals(Object obj) {
		if(!(obj instanceof BaseballPlayer)) {
			return false;
		}
		
		boolean result = false;
		
		if (this.getTeam() == ((BaseballPlayer)obj).getTeam()) {
			result = true;
		}
		
		return result;
	}
	
	public int getBattingPosition() {
		return battingPosition;
	}
	public void setBattingPosition(int battingPosition) {
		this.battingPosition = battingPosition;
	}
	public String getBattingHand() {
		return battingHand;
	}
	public void setBattingHand(String battingHand) {
		this.battingHand = battingHand;
	}
	
	public void doThis() {
		System.out.println("You got a hit!");
	}
	
	public void startPlay() {
		System.out.println("The pitch has been thrown!");
	}
	
	public String toString() {
		return "Baseball Player" + "\n" + "Name: " + getFirstName() + " " + getMiddleInitial() + " " + getLastName() + "\n" + "Age: " + getAge() + "\n" + "Team: " + getTeam() +"\n" + "Position: " + getPosition() + "\n" +"Batting Position: " + battingPosition + "\n" + "Batting Hand: " + battingHand;
	}

	
}
