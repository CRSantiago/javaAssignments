
public interface StartPlay {
	
	public abstract void startPlay();

}
