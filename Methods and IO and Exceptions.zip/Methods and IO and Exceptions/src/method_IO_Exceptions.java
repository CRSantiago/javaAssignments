
/*
 * Christopher Santiago
 * 09/11/18

*/
import java.util.Scanner;
import java.io.*;

public class method_IO_Exceptions {

	public static void main(String[] args) {

		Scanner keyboard = new Scanner(System.in);

		int menuChoice;

		System.out.println("<----- Menu ----->");
		System.out.println("1: To see your name echoed back 20 times.");
		System.out.println("2: To see what your age would look like if it was doubled.");
		System.out.println("3: Enter a number between 3 and 50 and watch the shape that appears.");
		System.out.println("4. Exit program");
		menuChoice = keyboard.nextInt();

		// while loop to prompt user for menu choice until 4 is entered. Then breaks
		// from loop and they are given exit message
		while (menuChoice != 4) {

			// switch which takes in user menu choice and applies method according to choice
			switch (menuChoice) {

			case 1:
				// method to prompt user for name and create loop to echo back their names 20
				// times
				nameRepetition();
				break;

			case 2:
				// method to prompt user for age. double the age. print age, doubled aged and
				// whether or not they are a teenager
				ageDoubled();
				break;

			case 3:
				// method to prompt user for number between 3 and 50 to use to create triangle
				// shape based on input
				shapePrinter();
				break;

			case 4:
				break;

			default:
				System.out.println("You entered an invalid menu option. Please pick from the menu list.");
				break;
			}// end of switch

			//new menu after each loop iteration. 
			System.out.println("<----- Menu ----->");
			System.out.println("1: To see your name echoed back 20 times.");
			System.out.println("2: To see what your age would look like if it was doubled.");
			System.out.println("3: Enter a number between 3 and 50 and watch the shape that appears.");
			System.out.println("4. Exit program");
			menuChoice = keyboard.nextInt();

		} // end of while loop

		// exit program message
		System.out.println("Thanks for using my program. Have a good day!");

	}

	public static void nameRepetition() {

		Scanner keyboard2 = new Scanner(System.in);
		String userName;

		// prompts user to enter their name
		System.out.println("Enter your name: ");
		userName = keyboard2.nextLine();

		// loops to print name 20 times
		for (int i = 0; i < 20; i++) {

			System.out.println(userName);

		} // end of for loop

	}// end of nameRepetition method

	public static void ageDoubled() {

		Scanner keyboard3 = new Scanner(System.in);
		int age, ageDoubled;

		System.out.println("Enter your current age: ");
		age = keyboard3.nextInt();

		ageDoubled = age * 2;

		System.out.println("Your age is " + age + ".");
		System.out.println("Your age doubled is " + ageDoubled + ".");

		if (age > 19) {

			System.out.println("Since you are, " + age + " you are NOT a teenager anymore. Welcome to grown up life!");

		} else {

			System.out.println("Since you are, " + age + " you are a teenager. Enjoy it while it last!");

		} // end of if statement

	}// end of ageDouble method

	public static void shapePrinter() {

		// scanner and variable to store user input
		Scanner keyboard4 = new Scanner(System.in);
		int numberEntered;

		// prompts user for number to be used to create shape
		System.out.println("Enter a number between 3 and 50, and see what shape appears: ");
		numberEntered = keyboard4.nextInt();

		if (numberEntered >= 3 && numberEntered <= 50) {
			// for loop that creates the shape
			for (int i = 0; i < numberEntered; i++) {

				for (int j = 0; j < i + 1; j++) {

					System.out.print("x");

				} // end of nested for loop

				System.out.println();

			} // end of for loop
			
			//creates new file
			File triangle = new File("triangle.txt");
			try (PrintWriter pw = new PrintWriter(triangle)){
				
				for (int i = 0; i < numberEntered; i++) {

					for (int j = 0; j < i + 1; j++) {

						pw.print("x");

					} // end of nested for loop

					pw.println();

				} // end of for loop
				
				
			} catch (IOException ex) {
				
				System.out.println("Something has seem to have gone wrong.");
				
			}
			
		} else if (numberEntered <= 2) {
			
			System.out.println("The number you entered is too low.");
			
		} else {
			
			System.out.println("The number you entered is too high. ");
			
		}//end of if/else statements
	}//end of shapePrinter method
}
