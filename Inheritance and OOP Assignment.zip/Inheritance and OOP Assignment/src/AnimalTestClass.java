//Christopher Santiago
//10.21.18
//Inheritance and introduction to OOP

public class AnimalTestClass {

	public static void main(String[] args) {
		
		Dog leo = new Dog(10, 6, "Leo", "Pomeranian", "06/12/18");
		Cat lucy = new Cat(14, 6, "Lucy", 7);
		Bird king = new Bird(3, 10, 15, true);
		
		System.out.println(leo);
		System.out.println();
		System.out.println(lucy);
		System.out.println();
		king.setFlight(true);
		System.out.println(king);

	}

}
