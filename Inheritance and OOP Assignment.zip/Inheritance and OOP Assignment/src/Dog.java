
public class Dog extends Animal{
	
	private String name;
	private String breed;
	private String dob;
	
	public Dog(int weight, int height, String name, String breed, String dob) {
		super(weight, height);
		setName(name);
		setBreed(breed);
		setDob(dob);
		
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public String getBreed() {
		return breed;
	}

	public void setBreed(String breed) {
		this.breed = breed;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String toString() {
		
		String result;
		result = "Dog: " + name + "\n" + "Breed: " + breed + "\n" + "DOB: " + dob + "\n" + "Weight(in lbs): " + getWeight() + "\n" + "Height(in inches): " + getHeight();
		
		return result;
	}

}
