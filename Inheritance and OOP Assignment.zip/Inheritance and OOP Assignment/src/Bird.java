
public class Bird extends Animal {

	private int wingSpan;
	private boolean flight;
	
	public Bird(int weight, int height, int wingSpan, boolean flight) {
		
		super(weight,height);
		setWingSpan(wingSpan);
		
	}
	
	public int getWingSpan() {
		return wingSpan;
	}

	public void setWingSpan(int wingSpan) {
		this.wingSpan = wingSpan;
	}

	public void setFlight(boolean flight) {
		
		if(flight == true) {
			
			System.out.println("This bird can fly.");
			
		}else {
			
			System.out.println("This bird cannot fly.");
			
		}
		
	}
	
	public boolean canFly() {
		
		return flight;
		
	}
	
	public String toString() {
		
		String result;
		
		result = "This bird's wingspan is " + wingSpan + " inches." + "\n" + "This bird's weight is " + getWeight() + " ounces." + "\n" + "This bird's height is " + getHeight() + " inches.";
		
		return result;
	}
}
